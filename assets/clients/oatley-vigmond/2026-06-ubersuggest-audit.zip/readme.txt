
  Difficulty:
Hard - Requires high technical knowledge to fix.
Moderate - Requires some technical knowledge to fix.
Easy - Requires little technical knowledge to fix.
  SEO Impact:
High - Critical issues that must be fixed. They have the greatest effect on traffic and rankings.
Medium - Issues that affect traffic and rankings, but are not putting a website in critical SEO danger.
Low - Recommended fixes based on best practices. They have the least effect on traffic and rankings.
1. Problem: With duplicate <title> tags
Report file: duplicate_title_tags.csv
Description: It's very important that each of your pages have original and unique title tags. Duplicate title tags can make it more complicated to rank content in search results because search engine crawlers won't know which post to rank above the other. If you want to rank your pages without confusion or without having them compete with one another, creating unique and relevant title tags is incredibly important.
Solution: Go through your pages and make sure that all of the title tags are unique and that you don't have any duplicate title tags.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Have title duplicates
2. Problem: Blocked from appearing in search engines
Report file: page_blocked_from_crawling.csv
Description: Sometimes there are pages on your site that you don't want appearing in search results. The robots.txt file, Robots Meta Tag and X-Robots-Tag in the HTTP header are methods that you can use to tell search engines that you don’t want a specific URL shown in search results. It's extremely important that you know which pages you want search engines to discover and which ones you don’t. By blocking your pages via one of the methods above, you are telling search engine crawlers that you don’t want people to find your content.
Solution: Ensure that all of the pages on your site that you want to be indexed by search engines are not being accidentally blocked. If you find any pages that are blocked unintentionally, remove the existing Robots Meta Tag, X-Robots-Tag or robots.txt file directive that is currently in place.
Difficulty: Moderate
SEO Impact: High
Columns:
    1. URL
    2. Page block reason
3. Problem: With a <title> tag that is too long
Report file: title_tag_too_long.csv
Description: It is recommended to keep your title tag under 65 characters so you don't run the risk of having part of it cut out from the search results page.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Go through your pages and shorten any of your title tags that exceed 65 characters.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title long
4. Problem: With a <title> tag that is too short
Report file: title_tag_too_short.csv
Description: Title tags need to deliver an important idea to your potential readers in a few words. But the title tag can't be too short. If the title tag is less than 30 characters, it will be difficult for search engines to understand what the content is about and decreasing the likelihood of ranking.

To learn more about creating SEO-friendly title tags, check out {0} article.
Solution: Title tags need to deliver an important idea to your potential readers in a few words. But the title tag can't be too short. If the title tag is less than 30 characters, it will be difficult for search engines to understand what the content is about and decreasing the likelihood of ranking.

To learn more about creating SEO-friendly title tags, check out {0} article.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Title length
5. Problem: With a poorly formatted URL for SEO
Report file: seo_non_friendly_url.csv
Description: In order to create a URL that is truly SEO-friendly, one must take into account certain factors that Google deems important for rankings. Some of these factors include the length of the URL not exceeding 120 characters, how relevant the wording in the title is to the content in the post, avoiding symbols and underscores within the slug, inclusion of session IDs, too many different sub-folders, and so on.

To learn more about SEO-friendly URLs, check out {0} article.
Solution: Avoid overcomplicating your URL structure by only focusing on using keywords in your slug that are relevant to the content in the post. Your URL should only contain numbers, letters, and dashes, and you should avoid using extraneous characters such as: !, @, #, $, %, ^, &, *, (, ), [, ], ?, {, }, ;, :, “.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url
6. Problem: With URLs that are too long
Report file: seo_friendly_url_relative_length_check.csv
Description: URLs that have more than 120 characters may negatively impact your chances of ranking. Google prefers URLs below that character count. The more words you add in your URL, Google will think the URL is only relevant for specific long tail phrases versus broad and long tail phrases.

To learn more about SEO-friendly URLs, check out {0} article.
Solution: Make sure that all of your URLs moving forward don't exceed the 120-character limit.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url relative length check
7. Problem: Keywords check
Report file: seo_friendly_url_keywords_check.csv
Description: <b>Keywords Check</b> - This test will be looking for the consistency of page URL with meta tag keywords. If the keywords tag is empty or absent then the URL is being compared with the content of &lt;title&gt; tag.
Difficulty: Easy
SEO Impact: Medium
Columns:
    1. URL
    2. Seo friendly url keywords check
